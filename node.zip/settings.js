
module.exports = {
  chikieSecret: "booksbylee",
  db: 'book',
  host: 'localhost'
};















