// DB Connection
/*
var mongoose = require('mongoose');
var connection = mongoose.connect('mongodb://localhost/book', function(err){
  if(err){
    console.log('MongoDB连接失败');
  }else{
    console.log('MongoDB连接成功');
  }
});

exports.mongoose = mongoose;
exports.mongoose.connection = connection;
*/